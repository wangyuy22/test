const express = require("express");
const app = express();
const path = require("path");
const router = express.Router();

//add the router
app.use("/", router);

const HTML_DIR = path.join(__dirname);
app.use(express.static(HTML_DIR));

router.get("/", function (req, res) {
  res.sendFile(path.join(HTML_DIR + "/page.html"));
  //__dirname : It will resolve to your project folder.
});

app.listen(process.env.port || 3000);

console.log("Running at Port 3000");
